// Select the node that will be observed for mutations
const targetNode = document.body
// Options for the observer (which mutations to observe)
const config = { attributes: true, childList: true, subtree: true };

// Callback function to execute when mutations are observed
const callback = (mutationList, observer) => {
  for (const mutation of mutationList) {
    if (mutation.type === "attributes") {
      if (mutation.target === targetNode && mutation.attributeName === 'style') {
        targetNode.parentNode.removeAttribute('style')
        mutation.target.removeAttribute('style')
        targetNode.setAttribute('style', 'overflow: auto !important')
      } else {
        // const localName = mutation.target.localName
        // if (localName !== 'script' && localName !== 'style' && localName !== 'img' && localName !== 'iframe') {
        //   console.log(mutation.target)
        // }
      }
    } else {
      if (mutation.addedNodes.length) {
        const nodesArray = Array.from(mutation.addedNodes)
        nodesArray.forEach(child => {
          if (child.localName !== 'script' && child.localName !== 'style' && child.localName !== 'img' && child.localName !== 'iframe') {
            const elementRect = child.getBoundingClientRect();
            const viewportRect = {
              top: 0,
              left: 0,
              bottom: window.innerHeight,
              right: window.innerWidth
            };
          
            // Check if the element's bounding rectangle intersects with the viewport's bounding rectangle
            const isIntersecting = !(
              elementRect.bottom < viewportRect.top ||
              elementRect.top > viewportRect.bottom ||
              elementRect.right < viewportRect.left ||
              elementRect.left > viewportRect.right
            );
            if (!isIntersecting && (elementRect.width > 250 && elementRect.height > 250)) {
              child.setAttribute('style', 'display: none !important;')
            } else {
              const computedStyles = window.getComputedStyle(child)
              if (parseInt(computedStyles.zIndex) > 500) {
                child.setAttribute('style', 'display: none !important;')
              }
            }
          } 
        })
      }
    }
  }
};

// Create an observer instance linked to the callback function
const observer = new MutationObserver(callback);

observer.observe(targetNode, config);

setTimeout(() => {
  observer.disconnect()
}, 5000)
